console.log("Hello 我在使用 JavaScript !!")
console.log("嗨，我的 JavaScript 檔案被成功載入了！", "我的名字叫Kyle!")